###########################################################
#globs.py
#Store global variables for use in multiple files
###########################################################

#Global variables

map = ""      #Map array for tiles
fovMap = ""   #libtcod's FOV map
gameState = ""    #State of game
playerAction = ""   #Player's action
objects = []   #List to store all objects in game
player = ""  #Object that holds player

